from ISO_8859_1_Splitter import ISO_8859_1_Splitter

def Splitter(txt,stopwords=None,encoding='latin1'):
    return ISO_8859_1_Splitter(txt,stopwords)
