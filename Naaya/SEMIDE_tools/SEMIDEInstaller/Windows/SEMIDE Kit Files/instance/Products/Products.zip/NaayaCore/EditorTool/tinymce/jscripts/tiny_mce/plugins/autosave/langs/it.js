/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Mar. 1st, 2007
 * TinyMCE Version : 2.1.0
 */

tinyMCE.addToLang('',{
autosave_unload_msg : 'I cambiamenti andranno persi se si carica un\'altra pagina.'
});
