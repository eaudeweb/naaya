return context.getCatalogedObjectsCheckView(meta_type=context.get_constant('METATYPE_NYSTORY'), approved=1, topitem=1)
