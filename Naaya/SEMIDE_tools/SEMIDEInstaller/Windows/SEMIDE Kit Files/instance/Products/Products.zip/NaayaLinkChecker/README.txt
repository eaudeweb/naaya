This product is meant to check the links to remote websites.
It is used in a Naaya-type portal.

