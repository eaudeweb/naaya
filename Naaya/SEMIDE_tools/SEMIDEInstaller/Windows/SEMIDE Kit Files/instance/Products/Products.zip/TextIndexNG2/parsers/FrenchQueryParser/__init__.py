from FrenchQueryParser import Parser
