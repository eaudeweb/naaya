// FR lang variables
// Modified by keyko-web.net, last updated 2007-03-08, based on the work of Motte

tinyMCE.addToLang('emotions',{
title : 'Choisir une &eacute;motic&ocirc;ne',
desc : 'Ins&eacute;rer une &eacute;motic&ocirc;ne',
cool : 'Cool',
cry : 'Triste',
embarassed : 'Embarrass&eacute;',
foot_in_mouth : 'Oups !',
frown : 'M&eacute;content',
innocent : 'Innocent',
kiss : 'Bisou',
laughing : 'Mort de rire',
money_mouth : 'Sensur&eacute;',
sealed : 'Motus',
smile : 'Sourire',
surprised : 'Surprise',
tongue_out : 'Moqueur',
undecided : 'Perplexe',
wink : 'Clin d\'oeil',
yell : 'Horreur !'
});
