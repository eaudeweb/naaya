Usage:

- download ZopeTestCase from http://www.zope.org/Members/shh/ZopeTestCase;
- Extract the tarball into the lib/python/Testing directory of your Zope installation;

Windows
=======
- cd path\to\zope\instance
- bin\zopectl test -vp NaayaContent.NySemPublication

UNIX
====
- cd path/to/zope/instance
- bin/zopectl test -vp NaayaContent.NySemPublication
