// RO lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Insereaz&#259; / editeaz&#259; rigla orizontal&#259;',
insert_advhr_width : 'L&#259;&#355;ime',
insert_advhr_size : '&#206;n&#259;l&#355;ime',
insert_advhr_noshade : 'F&#259;r&#259; umbr&#259;'
});
