CatalogTool

This tool provides a catalog for Naaya CMF objects.
