/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Mar. 1st, 2007
 * TinyMCE Version : 2.1.0
 */

tinyMCE.addToLang('flash',{
title : 'Inserisci o modifica oggetto Flash',
desc : 'Inserisci o modifica oggetto Flash',
file : 'File Flash (.swf)',
size : 'Dimensioni',
list : 'Lista file',
props : 'Propriet&agrave;',
general : 'Generale'
});
