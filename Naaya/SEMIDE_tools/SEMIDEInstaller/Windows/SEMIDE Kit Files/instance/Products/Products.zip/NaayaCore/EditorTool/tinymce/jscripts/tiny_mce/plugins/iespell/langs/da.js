// DK lang variables - Transl.:Jan Moelgaard, Bo Frederiksen - Corr.:

tinyMCE.addToLang('',{
iespell_desc : 'Lav stavekontrol',
iespell_download : "ieSpell kan ikke findes. Klik p&aring; OK for at forts&aelig;tte til downloadsiden."
});

