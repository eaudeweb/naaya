Files containing Python source code for External Method should be
placed in this directory.  A freshly created instance should only
contain this README.txt file in this directory.
