This directory contains files created and maintained by the Zope
application server and related utilities while the server is running.
This can include the object database as well as supplemental files
(such as "pidfiles").  Log files are normally stored in the log/
directory in the instance home.
