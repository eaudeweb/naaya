This directory contains an "instance home" for the Zope application
server.  It contains the following directories:

  bin/         Scripts used to control the Zope instance
  etc/         Configuration files
  Extensions/  Python sources for External Methods
  log/         Log files
  Products/    Installed products specific to the instance
  var/         Run-time data files, including the object database
