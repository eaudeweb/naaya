FormsTool

This tool provides a container for Naaya CMF common forms (page templates).
