Additional products for your Zope instance should be installed in this
directory.  A freshly created instance should only contain this
README.txt file in this directory.
