tinyMCE.addI18n('he.template_dlg',{
title:"\u05EA\u05D1\u05E0\u05D9\u05D5\u05EA",
label:"\u05EA\u05D1\u05E0\u05D9\u05EA",
desc_label:"\u05EA\u05D9\u05D0\u05D5\u05E8",
desc:"Insert predefined template content",
select:"\u05D1\u05D7\u05E8 \u05EA\u05D1\u05E0\u05D9\u05EA",
preview:"\u05EA\u05E6\u05D5\u05D2\u05D4 \u05DE\u05E7\u05D3\u05D9\u05DE\u05D4",
warning:"Warning: Updating a template with a different one may cause data loss.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"January,February,March,April,May,June,July,August,September,October,November,December",
months_short:"Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec",
day_long:"\u05E8\u05D0\u05E9\u05D5\u05DF,\u05E9\u05E0\u05D9,\u05E9\u05DC\u05D9\u05E9\u05D9,\u05E8\u05D1\u05D9\u05E2\u05D9,\u05D7\u05DE\u05D9\u05E9\u05D9,\u05E9\u05D9\u05E9\u05D9,\u05E9\u05D1\u05EA",
day_short:"\u05E8\u05D0\u05E9\u05D5\u05DF,\u05E9\u05E0\u05D9,\u05E9\u05DC\u05D9\u05E9\u05D9,\u05E8\u05D1\u05D9\u05E2\u05D9,\u05D7\u05DE\u05D9\u05E9\u05D9,\u05E9\u05D9\u05E9\u05D9,\u05E9\u05D1\u05EA"
});