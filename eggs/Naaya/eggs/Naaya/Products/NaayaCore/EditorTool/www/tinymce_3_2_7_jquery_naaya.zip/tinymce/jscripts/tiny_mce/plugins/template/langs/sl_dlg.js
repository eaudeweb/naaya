tinyMCE.addI18n('sl.template_dlg',{
title:"Predloge",
label:"Predloga",
desc_label:"Opis",
desc:"Vstavi pripravljeno vsebino predloge",
select:"Izberite predlogo",
preview:"Predogled",
warning:"Opozorilo: posodabljanje predloge lahko pripelje od izgube podatkov.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"januar,februar,marec,april,maj,junij,julij,avgust,september,oktober,november,december",
months_short:"jan,feb,mar,apr,maj,jun,jul,avg,sep,okt,nov,dec",
day_long:"nedelja,ponedeljek,torek,sreda,\u010Detrtek,petek,sobota,nedelja",
day_short:"ned,pon,tor,sre,\u010Det,pet,sob,ned"
});