TranslationsTool

This tool provides a message catalog for Naaya CMF messages (labels).

If the TextIndexNG2 product is present then it will be used.
