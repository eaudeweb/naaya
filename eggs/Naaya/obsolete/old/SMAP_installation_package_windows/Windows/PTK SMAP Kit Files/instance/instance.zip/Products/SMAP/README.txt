SMAP - Zope product which works on top of Naaya
Property of the SMAP Clearing House
	(Euro-Mediterranean Programme for the Environment)
-----------------------------------------------


Requirements
-----------------------------------------------
Zope server version 2.7.5 (recommended)
Arabic locale installed (default: ar_DZ)

Zope server (DLLs):
- TextIndexNG related PYD files

Zope server (site-packages):
- feedparser.py

Zope instance (Products):
    *EIONET SVN*
    - Epoz
    - Naaya
    - NaayaBase
    - NaayaContent
    - NaayaCore
    - naayaHotfix
    - SMAP
    - Localizer
    - RDFCalendar
    - RDFSummary

    *Zope products*
    - TextIndexNG2
    - iHotfix
