/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Mar. 1st, 2007
 * TinyMCE Version : 2.1.0
 */

tinyMCE.addToLang('',{
insert_advhr_desc : 'Riga orizzontale',
insert_advhr_width : 'Larghezza',
insert_advhr_size : 'Altezza',
insert_advhr_noshade : 'Senza rilievo'
});
