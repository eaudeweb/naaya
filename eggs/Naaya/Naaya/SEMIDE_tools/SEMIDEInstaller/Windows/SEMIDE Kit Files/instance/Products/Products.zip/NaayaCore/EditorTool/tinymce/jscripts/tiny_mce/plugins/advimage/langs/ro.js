// RO lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'General',
tab_appearance : 'Aspect',
tab_advanced : 'Avansat',
general : 'General',
title : 'Titlu',
preview : 'Previzualizare',
constrain_proportions : 'Propor&#355;ii constr&#226;geri',
langdir : 'Direc&#355;ia limbii',
langcode : 'Cod limb&#259;',
long_desc : 'Descriere lung&#259; leg&#259;tur&#259;',
style : 'Stil',
classes : 'Clase',
ltr : 'St&#226;nga la dreapta',
rtl : 'Dreapta la st&#226;nga',
id : 'Id',
image_map : 'Hart&#259; imagine',
swap_image : 'Schimb&#259; imagine',
alt_image : 'Imagine alternativ&#259;',
mouseover : 'pentru mouse deasupra',
mouseout : 'pentru mouse afar&#259;',
misc : 'Diverse',
example_img : 'Aspect&nbsp;previzualizare&nbsp;imagine',
missing_alt : 'E&#351;ti sigur c&#259; vrei s&#259; continui f&#259;r&#259; includerea unei descrieri pentru imagine? F&#259;r&#259; aceasta, este posibil ca imaginea s&#259; nu fie accesibil&#259; utilizatorilor cu invaliditate, celor care folosesc un program �n mod text pentru navigarea pe internet sau celor care navigheaz&#259; cu imaginile dezactivate.'
});
