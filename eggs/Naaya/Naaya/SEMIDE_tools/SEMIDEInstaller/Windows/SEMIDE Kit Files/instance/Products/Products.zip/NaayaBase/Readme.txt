NaayaBase

This product provides base classes and behavior for Naaya CMF.
