// HU lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'V�zszintes vonal beilleszt�se / szerkeszt�se',
insert_advhr_width : 'Hossz�s�g',
insert_advhr_size : 'Sz�less�g',
insert_advhr_noshade : 'Nincs �rny�k'
});
