from GermanQueryParser import Parser
