/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Oct. 17th, 2006
 * TinyMCE Version : 2.0.7
 */

tinyMCE.addToLang('',{
iespell_desc : 'Esegui controllo ortografico',
iespell_download : "ieSpell non trovato. Fai clic su OK per visitare la pagina di download."
});

