** README

Please read OAIPaper.pdf in docs directory

Note :

On unix :
localedef -i fr_FR -f ISO-8859-1 fr_FR
set locale n zope.conf


