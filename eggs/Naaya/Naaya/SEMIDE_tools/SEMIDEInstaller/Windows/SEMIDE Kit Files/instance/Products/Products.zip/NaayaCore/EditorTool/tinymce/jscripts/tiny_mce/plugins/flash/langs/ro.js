// RO lang variables

tinyMCE.addToLang('flash',{
title : 'Insereaz&#259; / editeaz&#259; film Flash',
desc : 'Inserare / editare film Flash',
file : 'Fi&#351;ier-Flash (.swf)',
size : 'Dimensiune',
list : 'Fi&#351;iere Flash',
props : 'Propriet&#259;&#355;i Flash',
general : 'General'
});
