from FrenchQueryParser import Parser
