// RO lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Direc&#355;ia st&#226;nga la dreapta',
directionality_rtl_desc : 'Direc&#355;ia dreapta la st&#226;nga'
});
