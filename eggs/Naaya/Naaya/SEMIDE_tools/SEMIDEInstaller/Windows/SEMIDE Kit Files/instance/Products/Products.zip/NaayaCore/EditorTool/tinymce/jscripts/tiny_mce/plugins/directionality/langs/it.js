/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Mar. 1st, 2007
 * TinyMCE Version : 2.1.0
 */

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Direzione da sinistra a destra',
directionality_rtl_desc : 'Direzione da destra a sinistra'
});
