// RO lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Porne&#351;te verificarea ortografic&#259;',
iespell_download : "ieSpell nu a fost detectat. Apas&#259; OK pentru a merge la pagina de desc&#259;rcare."
});

