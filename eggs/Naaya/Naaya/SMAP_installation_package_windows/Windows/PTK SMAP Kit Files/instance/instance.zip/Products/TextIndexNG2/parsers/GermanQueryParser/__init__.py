from GermanQueryParser import Parser
