PropertiesTool

This tool provides a tool for configuring the portal.
